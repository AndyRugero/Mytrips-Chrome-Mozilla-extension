import{t as e}from"./assets/storage-njr5DcER.js";console.log(`[MyTrips Content Script] Injected on:`,window.location.hostname),new class{overlayContainer=null;activeDiscounts=[];constructor(){this.initMessageListener(),this.checkCurrentPageDiscounts()}initMessageListener(){typeof chrome<`u`&&chrome.runtime&&chrome.runtime.onMessage.addListener(e=>{e.type===`MYTRIPS_DISCOUNTS_FOUND`&&(this.activeDiscounts=e.discounts,this.renderOverlay())})}async checkCurrentPageDiscounts(){let e=window.location.hostname.toLowerCase();e.includes(`trip.com`)?this.activeDiscounts=[{id:`disc-1`,code:`TRIP10OFF`,merchant:`Trip.com`,domain:`trip.com`,discountText:`10% OFF`,description:`10% discount on global hotel bookings`,affiliateUrl:`https://www.trip.com/?allianceid=MYTRIPS_PARTNER`,isVerified:!0}]:e.includes(`cheapoair.com`)?this.activeDiscounts=[{id:`disc-2`,code:`FLYCHEAP20`,merchant:`CheapOair`,domain:`cheapoair.com`,discountText:`$20 OFF`,description:`$20 off flight bookings`,affiliateUrl:`https://www.cheapoair.com/?fp_affiliate=MYTRIPS_PARTNER`,isVerified:!0}]:e.includes(`booking.com`)&&(this.activeDiscounts=[{id:`disc-3`,code:`BOOKINGSAFE5`,merchant:`Booking.com`,domain:`booking.com`,discountText:`5% CASHBACK`,description:`5% reward credit on hotel stay`,affiliateUrl:`https://www.booking.com/?aid=MYTRIPS_PARTNER`,isVerified:!0}]),this.activeDiscounts.length>0&&this.renderOverlay()}extractTravelDetails(){let e=document.title||`Saved Travel Item`,t=window.location.hostname,n=document.body.innerText.match(/(\$|€|£)\s?(\d{2,4})/),r=n?parseFloat(n[2]):150,i=n?n[1]===`€`?`EUR`:n[1]===`£`?`GBP`:`USD`:`USD`;return{id:`h-`+Date.now(),name:e.substring(0,50),checkInDate:new Date().toISOString().split(`T`)[0],checkOutDate:new Date(Date.now()+2592e5).toISOString().split(`T`)[0],price:r,currency:i,location:t,bookingUrl:window.location.href}}autoFillPromoCode(e){let t=[`input[name*="promo" i]`,`input[name*="coupon" i]`,`input[name*="voucher" i]`,`input[name*="gutschein" i]`,`input[placeholder*="promo" i]`,`input[placeholder*="coupon" i]`,`input[placeholder*="voucher" i]`,`input[placeholder*="gutschein" i]`,`input[id*="promo" i]`,`input[id*="coupon" i]`,`input[id*="voucher" i]`,`input[id*="gutschein" i]`],n=!1;for(let r of t){let t=document.querySelector(r);if(t){t.value=e,t.dispatchEvent(new Event(`input`,{bubbles:!0})),t.dispatchEvent(new Event(`change`,{bubbles:!0})),t.style.border=`2px solid #10b981`,n=!0;break}}n?alert(`🎉 MyTrips: Applied discount code "${e}"!`):(navigator.clipboard.writeText(e),alert(`📋 Code "${e}" copied to clipboard! Paste it in the promo code box at checkout.`))}renderOverlay(){if(this.overlayContainer)return;let t=this.activeDiscounts[0],n=document.createElement(`div`);n.id=`mytrips-extension-root`,n.style.cssText=`
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;let r=n.attachShadow({mode:`open`});r.innerHTML=`
      <style>
        .card {
          width: 310px;
          background: #ffffff;
          color: #1e293b;
          border: 1px solid #e2e8f0;
          border-radius: 16px;
          padding: 16px;
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
          animation: slideIn 0.3s ease-out;
          font-family: -apple-system, BlinkMacSystemFont, "Plus Jakarta Sans", "Segoe UI", Roboto, sans-serif;
        }
        @keyframes slideIn {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
          padding-bottom: 8px;
          border-bottom: 1px solid #f1f5f9;
        }
        .title {
          font-weight: 700;
          font-size: 13px;
          color: #2563eb;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .close-btn {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          color: #64748b;
          font-size: 14px;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .close-btn:hover {
          background: #f1f5f9;
        }
        .discount-badge {
          background: #eff6ff;
          border: 1px solid #bfdbfe;
          padding: 12px;
          border-radius: 12px;
          margin-bottom: 12px;
        }
        .code-title {
          font-size: 10px;
          font-weight: 700;
          color: #1d4ed8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 4px;
        }
        .code-val {
          font-size: 15px;
          font-weight: 800;
          color: #0f172a;
        }
        .btn-primary {
          width: 100%;
          background: #2563eb;
          color: #ffffff;
          border: none;
          font-weight: 700;
          font-size: 12px;
          padding: 9px;
          border-radius: 10px;
          cursor: pointer;
          margin-bottom: 8px;
          transition: background 0.2s;
        }
        .btn-primary:hover {
          background: #1d4ed8;
        }
        .btn-secondary {
          width: 100%;
          background: #f8fafc;
          color: #334155;
          border: 1px solid #e2e8f0;
          font-weight: 600;
          font-size: 12px;
          padding: 8px;
          border-radius: 10px;
          cursor: pointer;
        }
        .btn-secondary:hover {
          background: #f1f5f9;
        }
      </style>
      <div class="card">
        <div class="header">
          <div class="title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.7 5.2c.3.4.8.5 1.3.3l.5-.3c.4-.2.6-.6.5-1.1z"/></svg>
            MyTrips Assistant
          </div>
          <button class="close-btn" id="closeBtn">✕</button>
        </div>
        <div class="discount-badge">
          <div class="code-title">PROMO CODE FOUND FOR ${t.merchant.toUpperCase()}</div>
          <div class="code-val">${t.code} — (${t.discountText})</div>
        </div>
        <button class="btn-primary" id="applyBtn">Apply Code & Save</button>
        <button class="btn-secondary" id="saveTripBtn">Save Item to Itinerary</button>
      </div>
    `,document.body.appendChild(n),this.overlayContainer=n,r.getElementById(`closeBtn`)?.addEventListener(`click`,()=>{n.remove(),this.overlayContainer=null}),r.getElementById(`applyBtn`)?.addEventListener(`click`,()=>{this.autoFillPromoCode(t.code)}),r.getElementById(`saveTripBtn`)?.addEventListener(`click`,async()=>{let t=this.extractTravelDetails(),n=(await e.getTrips())[0];n||={id:`trip-`+Date.now(),title:`My Next Adventure`,destination:t.location||`Global`,startDate:new Date().toISOString().split(`T`)[0],endDate:new Date(Date.now()+6048e5).toISOString().split(`T`)[0],budgetLimit:2e3,currency:`EUR`,hotels:[],flights:[],activities:[],packingList:[],createdAt:new Date().toISOString()},n.hotels.push(t),await e.saveTrip(n),alert(`✅ Saved "${t.name}" to trip "${n.title}"!`)})}};